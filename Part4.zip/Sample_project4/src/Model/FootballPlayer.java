/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author HP
 */
public class FootballPlayer extends Person implements TableMember{
   protected int number;
   protected String position;
   
   private ArrayList<String> attributenames = new ArrayList<>();
   private ArrayList<String> attributes = new ArrayList<>();
   public FootballPlayer()
   {
      super();
      name = "";
      position = "";    
      
      //Add attribute names to an ArrayList
      attributenames.add("number");
      attributenames.add("position");
      attributenames.add("name");
      attributenames.add("height");
      attributenames.add("weight");
      attributenames.add("hometown");
      attributenames.add("highSchool");
            
   }
   public FootballPlayer(int number, String name, String position, int feet, int inches, int weight, String hometown, String highSchool)
   {
      super(name, feet, inches, weight, hometown, highSchool);      
      this.number = number;
      this.position = position;
      
      //Add attribute names to an ArrayList
      attributenames.add("number");
      attributenames.add("position");
      attributenames.add("name");
      attributenames.add("height");
      attributenames.add("weight");
      attributenames.add("hometown");
      attributenames.add("highSchool");
            
   }
   public int getNumber()
   {
      return this.number;
   }
   public String getPosition()
   {
      return this.position;
   }

   public void setNumber(int number)
   {      
      this.number = number;
   }
   public void setPosition(String position)
   {
      this.position = position;
   }
   
   @Override
   public String toString()
   {
      
      String output = super.toString();
      output = output + "\nNumber : " + this.getNumber();
      output = output + "\nPosition : " + this.getPosition();
      return output;      
   }
   @Override
   public String getAttribute(int n)
   {
      attributes = new ArrayList<>();
      
      //Add attributes to an ArrayList
      attributes.add(Integer.toString(number));
      attributes.add(position);      
      attributes.add(name);
      attributes.add(super.height.toString());
      attributes.add(Integer.toString(weight));
      attributes.add(hometown);
      attributes.add(highSchool);
      
      return attributes.get(n);
   }
   @Override
   public ArrayList<String> getAttributes()
   {
      attributes = new ArrayList<>();
      
      //Add attributes to an ArrayList
      attributes.add(Integer.toString(number));
      attributes.add(position);      
      attributes.add(name);
      attributes.add(super.height.toString());
      attributes.add(Integer.toString(weight));
      attributes.add(hometown);
      attributes.add(highSchool);

      return attributes;
   }
   @Override
   public String getAttributeName(int n)
   {
      return attributenames.get(n);
   }
   
   @Override
   public ArrayList<String> getAttributeNames()
   {
      return attributenames;
   }
   
}
