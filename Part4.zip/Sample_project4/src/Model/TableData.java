/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
import java.util.ArrayList;
public interface TableData {
 
   public ArrayList<FootballPlayer> getTable();
   
   public ArrayList<String> getHeaders();
   
   public ArrayList<String> getLine(int line);
   
   public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine);
}
