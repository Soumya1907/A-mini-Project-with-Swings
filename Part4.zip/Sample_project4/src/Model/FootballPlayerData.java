/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;

/**
 *
 * @author HP
 */
public class FootballPlayerData implements TableData{
    private ArrayList<FootballPlayer> players;
   private FootballPlayer fp = new FootballPlayer();
   
   public FootballPlayerData()
   {
      players = new ArrayList<>();
      loadTable();
   }
   
   public void ReadPlayersFromXML()
   {
      try
      {         
         FootballPlayer fp;
         XMLDecoder decoder;
         decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("FootballPlayerTable.xml")));
         fp = new FootballPlayer();
         
         while(fp != null)
         {
            try
            {
               fp = (FootballPlayer) decoder.readObject();
               players.add(fp);
            }
            catch (ArrayIndexOutOfBoundsException theend)
            {
               //System.out.println("end of file");
               break;
            }
         }
         
         decoder.close();         
      }
      catch (Exception xx)
      {
         xx.printStackTrace();         
      }
   }
   
   public void loadTable()
   {
      ReadPlayersFromXML();
   }
   @Override
   public ArrayList<FootballPlayer> getTable()
   {
      return players;
   }
   @Override
   public ArrayList<String> getHeaders()
   {
      return fp.getAttributeNames();
   }
   @Override
   public ArrayList<String> getLine(int line)
   {
      return players.get(line).getAttributes();
   }
   @Override
   public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine)
   {
      ArrayList<ArrayList<String>> lines = new ArrayList<>();
      
      for(int i = firstLine ; i <= lastLine ; i++)
      {
         lines.add(getLine(i));
      }
      
      return lines;
   }

}
