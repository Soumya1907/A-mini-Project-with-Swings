/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class Person {
   protected String name;
   protected Height height;
   protected int weight;
   protected String hometown;
   protected String highSchool;
   
   public Person()
   {
      name = "";
      height = new Height();
      weight = -1;
      hometown = "";
      highSchool = "";
   }
   
   public Person(String name, int feet, int inches, int weight, String hometown, String highSchool)
   {
      this.name = name;
      this.height = new Height(feet,inches);
      this.weight = weight;
      this.hometown = hometown;
      this.highSchool = highSchool;
   }
   
   //Accessor methods
   public String getName()
   {
      return this.name;
   }
   public Height getHeight()
   {
      return this.height;
   }   
   public int getWeight()
   {
      return this.weight;
   }
   public String getHometown()
   {
      return this.hometown;
   }
   public String getHighSchool()
   {
      return this.highSchool;
   }
   
   //Mutator methods
   public void setName(String name)
   {
      this.name = name;
   }
   public void setHeight(Height height)
   {
      this.height = height;
   }
   public void setWeight(int weight)
   {
      this.weight = weight;
   }
   public void setHometown(String hometown)
   {
      this.hometown = hometown;
   }
   public void setHighSchool(String highSchool)
   {
      this.highSchool = highSchool;
   }
   @Override
   public String toString()
   {
       String output;
      
      output = "Name : " + this.getName();
      output = output + "\nHeight : " + this.getHeight().toString();
      output = output + "\nWeight : " + this.getWeight() ;
      output = output + "\nHome Town : " + this.getHometown();
      output = output + "\nHigh School : " + this.getHighSchool();
      return output;      
   }
}
