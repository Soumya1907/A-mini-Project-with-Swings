/*
 * Soumya's Project
 * Please dont copy  * 
 */

/**
 *
 * @author HP
 */

    public class App {
   
   public static void main(String[] args)
   {
      View.View view1 = new View.View();
      Model.Model model1 = new Model.Model();
      Controller.Controller controller1 = new Controller.Controller(model1, view1);
   }
    
}

