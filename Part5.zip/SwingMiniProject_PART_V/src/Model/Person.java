/*
 * Soumya's Project
 * Please dont copy  * 
 */
package Model;

/**
 *
 * @author Soumya
 */
public class Person {
   
   protected String name;
   protected Height height;
   protected int weight;
   protected String hometown;
   protected String highSchool;
   
   public Person()
   {
      name = "";
      height = new Height();
      weight = -1;
      hometown = "";
      highSchool = "";
   }
   
   public Person(String name, int feet, int inches, int weight, String hometown, String highSchool)
   {
      this.name = name;
      this.height = new Height(feet,inches);
      this.weight = weight;
      this.hometown = hometown;
      this.highSchool = highSchool;
   }
   
   //Accessor methods
   public String getName()
   {
      return this.name;
   }
   public Height getHeight()
   {
      return this.height;
   }   
   public int getWeight()
   {
      return this.weight;
   }
   public String getHometown()
   {
      return this.hometown;
   }
   public String getHighSchool()
   {
      return this.highSchool;
   }
   
   //Mutator methods
   public void setName(String name)
   {
      this.name = name;
   }
   public void setHeight(Height height)
   {
      this.height = height;
   }
   public void setWeight(int weight)
   {
      this.weight = weight;
   }
   public void setHometown(String hometown)
   {
      this.hometown = hometown;
   }
   public void setHighSchool(String highSchool)
   {
      this.highSchool = highSchool;
   }

   /**
    * Returns the name, height, weight, hometown and highSchool attributes 
    * in the format :
    *    
    *    Name : insert name of person
    *    Height : F'I"
    *    Weight : X lbs
    *    Home Town : insert hometown of person
    *    High School : insert highSchool of person
    * 
    * Where F is the value of feet and I is the value of inches. Eg :
    *
    *    5"2' 
    *    
    * Where we consider value of feet to be 5 and inches to be 2.
    * 
    * Similarly, X is the value of weight. Eg :
    *
    *    240 lbs
    * 
    * Where we consider the value of weight to be 240.
    * 
    * Other attributes are displayed as shown above.
    * 
    * @return  the name, height, weight, hometown and highSchool attributes 
    */
   @Override
   public String toString()
   {
      //Building the string output to return.
      String output = "Name : " + this.getName();
      output = output + "\nHeight : " + this.getHeight().toString();
      output = output + "\nWeight : " + this.getWeight() + " lbs";
      output = output + "\nHome Town : " + this.getHometown();
      output = output + "\nHigh School : " + this.getHighSchool();
      return output;      
   }
   
}
