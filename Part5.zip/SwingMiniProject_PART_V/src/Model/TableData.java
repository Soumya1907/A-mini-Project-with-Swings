/*
 * Soumya's Project
 * Please dont copy  * 
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Soumya
 */
interface TableData {
   
   public void loadTable();
   
   public ArrayList<FootballPlayer> getTable();
   
   public ArrayList<String> getHeaders();
   
   public ArrayList<String> getLine(int line);
   
   public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine);
   
}
