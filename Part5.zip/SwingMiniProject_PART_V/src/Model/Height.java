/*
 * Soumya's Project
 * Please dont copy  * 
 */
package Model;

/**
 *
 * @author Soumya
 */
public class Height {
   
   private int feet;
   private int inches;
   
   public Height()
   {
      feet = 0;
      inches = 0;
   }
   
   public Height(int feet,int inches)
   {
      this.feet = feet;
      this.inches = inches;
   }
      
   //Accessor methods
   public int getFeet()
   {
      return this.feet;
   }
   public int getInches()
   {
      return this.inches;
   }
   
   //mutator methods
   public void setFeet(int feet)
   {
      this.feet = feet;
   }
   public void setInches(int inches)
   {
      this.inches = inches;
   }
    
   /**
    * Returns the feet and inches constituting the height in the format :
    *    
    *    F'I"
    * 
    * Where F is the value of feet and I is the value of inches. Eg :
    *
    *    5"2' 
    *    
    * Where we consider value of feet to be 5 and inches to be 2.
    * 
    * @return  the feet and inches constituting the height in a specific format 
    */
   @Override
   public String toString()
   {
      return feet+"\'"+inches+"\"";
   }
   
}
