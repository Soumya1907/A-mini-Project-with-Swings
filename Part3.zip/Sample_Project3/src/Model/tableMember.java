/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.util.ArrayList;
/**
 *
 * @author HP
 */
public interface tableMember {
    
    public String getAttribute(int n);
    public String getAttributeName(int n);
    public ArrayList<String>getAttribute();
    public ArrayList<String>getAttributeName();
}
