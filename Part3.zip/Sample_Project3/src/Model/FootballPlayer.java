/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.util.ArrayList;
/**
 *
 * @author HP
 */

class FootballPlayer extends Person implements tableMember{
    private int number;
    
    private String position;
    private ArrayList<String> attributenames = new ArrayList<>();
    private ArrayList<String> attributes = new ArrayList<>();
    

    // default constructor 

    public FootballPlayer() {
        number=0;
        name="";
        position="";
        height=new Height();
        weight=0;
        homeTown="";
        highSchool="";
    }
   
    // Parameterized constructor
   
    public FootballPlayer(int number, String name, String position, Height height,
            int weight, String homeTown, String highSchool) {
        this.number = number;
        this.name = name;
        this.position = position;
        this.height = height;
        this.weight = weight;
        this.homeTown = homeTown;
        this.highSchool = highSchool;
    }

    // Getter and setter of Football Player class
    
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public String getPostion() {
        return position;
    }

    public void setPostion(String postion) {
        this.position = postion;
    }

    @Override
    public Height getHeight() {
        
        return height;
    }
 /* the height object which is given in the FootballPlayer class will be 
    is initialised by the height object of the parameter of the set
    height
    */
    @Override
    public void setHeight(Height height) {
        this.height = height ; 
    }
    @Override
    public int getWeight() {
        return weight;
    }
    @Override
    public void setWeight(int weight) {
        this.weight = weight;
    }
    @Override
    public String getHomeTown() {
        return homeTown;
    }
    @Override
    public void setHomeTown(String homeTown) {
        this.homeTown = homeTown;
    }
    @Override
    public String getHighSchool() {
        return highSchool;
    }
    @Override
    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }



    @Override
    public String getAttributeName(int n) {
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> getAttribute() {
        ArrayList<String> a= new ArrayList<>();
        a.add(getName());
        a.add(getPostion() );
       
        a.add(getHomeTown() );
        a.add(getHighSchool() );
        return(a);

    }
    
    @Override
    public ArrayList<String> getAttributeName() {
        ArrayList<String> ab= new ArrayList<>();
        ab.add(getName());
        return(ab);

    } 
    @Override
    public String toString()
    {
       //Building the string output to return.
       String output = super.toString();
       output = output + "\nNumber : " + this.getNumber();
       output = output + "\nPosition : " + this.getPostion();
       return output;      
    }
    @Override
   public String getAttribute(int n)
   {
      attributes = new ArrayList<>();
      
      //Add attributes to an ArrayList
      attributes.add(Integer.toString(number));
      attributes.add(position);      
      attributes.add(name);
      attributes.add(super.height.toString());
      attributes.add(Integer.toString(weight));
      attributes.add(homeTown);
      attributes.add(highSchool);
      
      return attributes.get(n);
   }
   
   public ArrayList<String> getAttributes()
   {
      attributes = new ArrayList<>();
      
      //Add attributes to an ArrayList
      attributes.add(Integer.toString(number));
      attributes.add(position);      
      attributes.add(name);
      attributes.add(super.height.toString());
      attributes.add(Integer.toString(weight));
      attributes.add(homeTown);
      attributes.add(highSchool);

      return attributes;
   }
   
}
