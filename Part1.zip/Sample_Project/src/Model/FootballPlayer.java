/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class FootballPlayer {
    private int number;
    private String name;
    private String position;
    private Height height;
    private int weight;
    private String homeTown;
    private String highSchool;

    // default constructor 

    public FootballPlayer() {
        number=0;
        name="";
        position="";
        height=new Height();
        weight=0;
        homeTown="";
        highSchool="";
    }

   
    // Parameterized constructor
   
    public FootballPlayer(int number, String name, String position, Height height, int weight, String homeTown, String highSchool) {
        this.number = number;
        this.name = name;
        this.position = position;
        this.height = height;
        this.weight = weight;
        this.homeTown = homeTown;
        this.highSchool = highSchool;
    }

    // Getter and setter of Football Player class
    
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPostion() {
        return position;
    }

    public void setPostion(String postion) {
        this.position = postion;
    }

    public Height getHeight() {
        
        return height;
    }
 /* the height object which is given in the FootballPlayer class will be 
    is initialised by the height object of the parameter of the set
    height
    */
    public void setHeight(Height height) {
        this.height = height ; 
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHomeTown() {
        return homeTown;
    }

    public void setHomeTown(String homeTown) {
        this.homeTown = homeTown;
    }

    public String getHighSchool() {
        return highSchool;
    }

    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }
}
