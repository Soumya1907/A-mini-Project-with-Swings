/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class OffensiveLine {
    FootballPlayer center ;
    FootballPlayer offensiveGuard ;
    FootballPlayer offensiveTackle;

    public OffensiveLine() {
        center = new FootballPlayer(1, "A", "Defender", new Height(7, 8), 58, "howrah", "Rmmhs");
        offensiveGuard = new FootballPlayer(2, "B", "GoalKeeper", new Height(6, 8), 50, "kolkata", "Rmmhs");
        offensiveTackle = new FootballPlayer(3, "C", "Attacker", new Height(7, 8), 55, "hoogly", "Rmmhs");   
    }
    
    public OffensiveLine(FootballPlayer center, FootballPlayer offensiveGuard, FootballPlayer offensiveTackle) {
        this.center = center;
        this.offensiveGuard = offensiveGuard;
        this.offensiveTackle = offensiveTackle;
    }

    public FootballPlayer getCenter() {
        return center;
    }

    public void setCenter(FootballPlayer center) {
        this.center = center;
    }

    public FootballPlayer getOffensiveGuard() {
        return offensiveGuard;
    }

    public void setOffensiveGuard(FootballPlayer offensiveGuard) {
        this.offensiveGuard = offensiveGuard;
    }

    public FootballPlayer getOffensiveTackle() {
        return offensiveTackle;
    }

    public void setOffensiveTackle(FootballPlayer offensiveTackle) {
        this.offensiveTackle = offensiveTackle;
    }
    public int avarageWeight(){
        int avg=(center.getWeight()+offensiveGuard.getWeight()+offensiveTackle.getWeight())/3;
        return avg;
    }
    /*center offensiveGuard offensiveTackle*/
    @Override
    public String toString(){
        
        return "\n"+center.getName()+" "+center.getNumber()+" "+center.getHeight()+" "+center.getWeight()+
                " "+center.getPostion()+
                " "+center.getHighSchool()+" "+center.getHomeTown()+" \n"+offensiveGuard.getName()+
                " "+offensiveGuard.getNumber()+" "+offensiveGuard.getHeight()+" "+offensiveGuard.getWeight()+
                        " "+offensiveGuard.getPostion()+" "+offensiveGuard.getHomeTown()+
                                " "+offensiveGuard.getHighSchool()+ "\n"+ offensiveTackle.getName()
                +" "+offensiveTackle.getNumber()+" "+offensiveTackle.getHeight()+" "+offensiveTackle.getWeight()
                +" "+offensiveTackle.getPostion()+" "+offensiveTackle.getHomeTown()+" "+offensiveTackle.getHighSchool();
    }
    
    
}
