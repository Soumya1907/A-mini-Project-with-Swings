/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class Height {
    private int feet;
    private int inch;

    public Height() {
        feet=0;
        inch=0;
    }
    
    public Height(int feet,int inch){
        this.feet=feet;
        this.inch=inch;
    }

    public int getFeet() {
        return feet;
    }

    public void setFeet(int feet) {
        this.feet = feet;
    }

    public int getInch() {
        return inch;
    }

    public void setInch(int inch) {
        this.inch = inch;
    }
    
    @Override
    public String toString(){
        
        return feet+"\'"+inch+" \" ";
    }
   public double toDecimal(){
        double total;
        if(inch< 12){
           total= feet*12+inch;  
        }
        else{
           total= feet*12+inch/12+ inch%12;  
        }
        return total;
   }
}
