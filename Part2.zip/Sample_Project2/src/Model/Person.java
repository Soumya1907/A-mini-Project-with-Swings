/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class Person {
   
    String name;
    Height height;
    int weight;
    String homeTown;
    String highSchool;

    public Person() {
        
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.homeTown = homeTown;
        this.highSchool = highSchool;
    }

    public Person(String name, Height height, int weight, String homeTown, String highSchool) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.homeTown = homeTown;
        this.highSchool = highSchool;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Height getHeight() {
        return height;
    }

    public void setHeight(Height height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHomeTown() {
        return homeTown;
    }

    public void setHomeTown(String homeTown) {
        this.homeTown = homeTown;
    }

    public String getHighSchool() {
        return highSchool;
    }

    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }
    
    
}
