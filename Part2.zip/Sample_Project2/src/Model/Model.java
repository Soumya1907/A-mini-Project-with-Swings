/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author HP
 */
public class Model {
    FootballPlayer f1;
    FootballPlayer f2;
    FootballPlayer f3;
 
    public Model() {
        f1 = new FootballPlayer(1, "A", "Defender", new Height(7, 8), 58, "howrah", "Rmmhs");
        f2 = new FootballPlayer(2, "B", "GoalKeeper", new Height(6, 8), 50, "kolkata", "Rmmhs");
        f3 = new FootballPlayer(3, "C", "Attacker", new Height(7, 8), 55, "hoogly", "Rmmhs");   
    }
    public void compare() {
        Height h1 = f1.getHeight();
        Height h2 = f2.getHeight();
        Height h3 = f3.getHeight();
        
        if (h1.toDecimal() > h2.toDecimal() && h1.toDecimal() > h3.toDecimal()) {
            System.out.println(f1.getName() + " is tallest");
        } else if (h2.toDecimal() > h1.toDecimal() && h2.toDecimal() > h3.toDecimal()) {
            System.out.println(f2.getName() + " is tallest");
        } else if (h3.toDecimal() > h2.toDecimal() && h3.toDecimal() > h1.toDecimal()) {
            System.out.println(f3.getName() + " is tallest");
        } else if (h1.toDecimal() == h2.toDecimal() && h1.toDecimal() > h3.toDecimal()) {
            System.out.println("Both " + f1.getName() + "and " + f2.getName() + " are tallest");
        } else if (h3.toDecimal() == h2.toDecimal() && h3.toDecimal() > h1.toDecimal()) {
            System.out.println("Both " + f3.getName() + " and " + f2.getName() + " are tallest");
        } else if (h1.toDecimal() == h3.toDecimal() && h1.toDecimal() > h2.toDecimal()) {
            System.out.println("Both "+f3.getName() +" and "+ f1.getName()+" are tallest");
        } else {
            System.out.println("All are tallest and of same height");
        }
    }
    public void OffensiveLine(){
        OffensiveLine o= new OffensiveLine();
        System.out.println("Information about Offensive Line is as follows\n"+o.toString());
        System.out.println("Avarage Weight of Offensive Line is = "+o.avarageWeight());
    }
}
