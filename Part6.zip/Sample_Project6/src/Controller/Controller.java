/*
 * Here comes the text of your license
 * Please Donot copy my project.n 
 *  Call 8420762376 and understand it. Do it on you own
 */
package Controller;

import java.awt.event.*;

/**
 *
 * @author Soumya
 */
public class Controller {
   
   Model.Model model; 
   View.View view;
   
   int firstLine;
   int lastLine;
   int FpDataSize;
   int numberOfLines;
   
   public Controller(Model.Model m, View.View v) 
   { 
      model = m; 
      view = v; 
      
      model.getFpData().setFirstLineToDisplay(0);
      model.getFpData().setLinesBeingDisplayed(20);
      
      firstLine = model.getFpData().getFirstLineToDisplay();
      lastLine = model.getFpData().getLinesBeingDisplayed() + firstLine - 1;
      numberOfLines = model.getFpData().getLinesBeingDisplayed();
      FpDataSize = model.getFpData().getTable().size();
      
      model.getFpData().setLastLineToDisplay(model.getFpData().getLinesBeingDisplayed() + model.getFpData().getFirstLineToDisplay() - 1);            
      
      view.CenterInitialSetup(model.getFpData().getLinesBeingDisplayed(), model.getFpData().getHeaders().size());
      view.CenterUpdate(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()), model.getFpData().getHeaders()); 
      addScrolling();
      
   }
   
   private void addScrolling()
   {
      view.getInitialFrame().getInitialPanel().getCp().addMouseWheelListener(
              new MouseWheelListener()
              {
                 @Override
                 public void mouseWheelMoved(MouseWheelEvent e)
                 {
                    int units = e.getUnitsToScroll();

                    if(lastLine + units < FpDataSize && firstLine + units >= 0)
                    {
                       firstLine += units;
                       lastLine += units;                       
                    }
                    
                    if(0 - firstLine >= units)
                    {
                       firstLine = 0;
                       lastLine = numberOfLines - 1;
                    }
                    else if(FpDataSize - lastLine <= units)
                    {
                       lastLine = FpDataSize - 1;
                       firstLine = lastLine - (numberOfLines - 1);
                    }
                    view.CenterUpdate(model.getFpData().getLines(firstLine, lastLine), model.getFpData().getHeaders());                    
                 }
              }
      );
   }
   
}
